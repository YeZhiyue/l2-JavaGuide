package ${PACKAGE_NAME};

#parse("File Header.java")
public enum ${NAME} {

    /**
     * @author 叶之越
     * Description 枚举常量
     * Date ${DATE}
     * Time ${TIME}
     */
    EatingItem_NAME_IS_EXIST_ERROR(10000, "菜单名已存在");


    /**
     * @author 叶之越
     * Description: 成员字段和构造器
     * Date: ${DATE}
     * Time: ${TIME}
     */
    private Integer code;
    private String msg;

    ${NAME}(Integer code, String msg) {
        this.code = code;
        this.msg = msg;
    }

    public Integer getCode() {
        return code;
    }

    public void setCode(Integer code) {
        this.code = code;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }
}
