package ${PACKAGE_NAME};

import lombok.Data;
import lombok.EqualsAndHashCode;

import java.io.Serializable;
#parse("File Header.java")
@Data
@EqualsAndHashCode(callSuper = false)
public class ${NAME} implements Serializable {
    
}
