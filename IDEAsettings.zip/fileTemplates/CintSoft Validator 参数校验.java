package ${PACKAGE_NAME};

import org.springframework.util.StringUtils;

#parse("File Header.java")
public class ${NAME} extends BaseValidator {

    /**
     * @param ${NAME}  前端传输的实体类
     * @description 新增宿舍参数验证
     * @author 叶之越
     * @email 739153436@qq.com
     * @date 2020/7/14 10:13
     */
    public static void insertValidate($CLASS ${NAME}) {
        if (StringUtils.isEmpty(${NAME}.) {
            throw new ParameterValidateException();
        }
    }

    /**
     * @param ${NAME}  前端传入的宿舍类
     * @description 更新参数验证
     * @author 叶之越
     * @email 739153436@qq.com
     * @date 2020/7/14 10:12
     */
    public static void updateValidate($CLASS ${NAME}) {
        if (StringUtils.isEmpty(${NAME}.getId())) {
            throw new ParameterValidateException("id不能为空");
        }
        // id传入之后插入相关的参数也不能为空
        insertValidate(${NAME});
    }
}

