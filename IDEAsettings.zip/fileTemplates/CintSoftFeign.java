package ${PACKAGE_NAME};

import com.cintsoft.ace.common.core.constant.ServiceNameConstants;
import com.cintsoft.ace.information.provider.api.entity.InformationInform;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

/**   使用方式：注入依赖，调用方法  @Resource
    private CompanyFeign companyFeign;
* 请求路径需要配置这个模块下面的路径
*/
@FeignClient(contextId = "informationFeign", value = ServiceNameConstants.INFORMATION_PROVIDER_SERVICE/*这里可以需要配置自己的服务名*/)
public interface ${NAME} {

    /**
     * @description
     * @author 叶之越
     * @email 739153436@qq.com
     * @date 2020/8/16 12:24
     */
    @PostMapping("/informationInform/invokeSaveInformByAdmin")
    Boolean invokeSaveInformByAdmin(@RequestBody InformationInform informationInform);

    /**
     * @description
     * @author 叶之越
     * @email 739153436@qq.com
     * @date 2020/8/16 12:23
     */
    @GetMapping("/informationInform/getInformDetailsById")
    InformationInform getInformDetailsById(String informId);
}
