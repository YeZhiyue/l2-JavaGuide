package ${PACKAGE_NAME};

import com.baomidou.mybatisplus.core.toolkit.Sequence;
import com.baomidou.mybatisplus.extension.plugins.OptimisticLockerInterceptor;
import com.cintsoft.ace.common.data.config.Base${NAME};
import org.mybatis.spring.mapper.MapperScannerConfigurer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * @description:
 * @author: van
 * @create: 2020-03-12 15:04
 */
@Configuration
public class ${NAME} extends Base${NAME} {

    /**
     * id 自动生成
     *
     * @return
     */
    @Bean
    public Sequence idGenerator() {
        return new Sequence();
    }

    /**
     * 相当于顶部的：
     * {@code @MapperScan("com.baomidou.springboot.mapper*")}
     * 这里可以扩展，比如使用配置文件来配置扫描Mapper的路径
     */
    @Bean
    public MapperScannerConfigurer mapperScannerConfigurer() {
        MapperScannerConfigurer scannerConfigurer = new MapperScannerConfigurer();
        scannerConfigurer.setBasePackage("com.cintsoft.ace.compete.provider.mapper");
        return scannerConfigurer;
    }

    /**
     * 乐观锁插件 配置
     *
     * @return
     */
    @Bean
    public OptimisticLockerInterceptor optimisticLockerInterceptor() {
        return new OptimisticLockerInterceptor();
    }
}
