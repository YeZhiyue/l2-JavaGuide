package ${PACKAGE_NAME};

import com.baomidou.mybatisplus.core.handlers.MetaObjectHandler;
import com.cintsoft.ace.common.security.bean.AceUser;
import com.cintsoft.ace.common.security.utils.SecurityUtils;
import org.apache.ibatis.reflection.MetaObject;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

/**
 * @description:
 * @author: van
 * @create: 2020-03-12 15:06
 */
@Component
public class ${NAME} implements MetaObjectHandler {

    /**
     * 自动生成新建时间戳
     *
     * @param metaObject
     */
    @Override
    public void insertFill(MetaObject metaObject) {
        // 也可以使用(3.3.0 该方法有bug请升级到之后的版本如`3.3.1.8-SNAPSHOT`)
        this.fillStrategy(metaObject, "createTime", System.currentTimeMillis());
        this.fillStrategy(metaObject, "version", 0);
        this.fillStrategy(metaObject, "deleted", 0);
        AceUser user = SecurityUtils.getUser();
        if (!StringUtils.isEmpty(user.getId())) {
            this.fillStrategy(metaObject, "createBy", user.getId());
        }
    }

    /**
     * 自动生成更新时间戳
     *
     * @param metaObject
     */
    @Override
    public void updateFill(MetaObject metaObject) {
        // 也可以使用(3.3.0 该方法有bug请升级到之后的版本如`3.3.1.8-SNAPSHOT`)
        this.fillStrategy(metaObject, "updateTime", System.currentTimeMillis());
        AceUser user = SecurityUtils.getUser();
        if (!StringUtils.isEmpty(user.getId())) {
            this.fillStrategy(metaObject, "updateBy", user.getId());
        }
    }
}
