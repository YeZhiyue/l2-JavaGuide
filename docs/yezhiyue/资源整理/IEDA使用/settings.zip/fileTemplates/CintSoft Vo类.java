package ${PACKAGE_NAME};

import lombok.Data;
import lombok.EqualsAndHashCode;

#parse("File Header.java")
@Data
@EqualsAndHashCode(callSuper = false)
public class ${NAME}{
    
}
