package ${PACKAGE_NAME};

import cn.hutool.core.util.ObjectUtil;
import com.cintsoft.ace.common.data.config.BaseMetaObjectHandler;
import com.cintsoft.ace.common.security.bean.AceUser;
import com.cintsoft.ace.common.security.utils.SecurityUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.ibatis.reflection.MetaObject;
import org.springframework.stereotype.Component;


/**
 * <p>项目名称: ace </p>
 * <p>描述: </p>
 * <p>创建时间: 2020-03-20 15:01 </p>
 *
 * @author wangzy
 * @version v1.0
 */
@Slf4j
@Component
public class ${NAME} extends BaseMetaObjectHandler {
    @Override
    public void insertFill(MetaObject metaObject) {
        metaObject.setValue("createTime", null);
        metaObject.setValue("updateTime", null);
        metaObject.setValue("createBy", null);
        metaObject.setValue("updateBy", null);
        this.strictInsertFill(metaObject, "createTime", Long.class, System.currentTimeMillis()); // 起始版本 3.3.0(推荐使用)
        //  获取用户信息
        AceUser aceUser = SecurityUtils.getUser();
        if (ObjectUtil.isNotEmpty(aceUser)) {
            this.strictInsertFill(metaObject, "createBy", String.class, aceUser.getId());
        }
        updateFill(metaObject);
    }

    @Override
    public void updateFill(MetaObject metaObject) {
        metaObject.setValue("updateTime", null);
        metaObject.setValue("updateBy", null);
        this.strictUpdateFill(metaObject, "updateTime", Long.class, System.currentTimeMillis()); // 起始版本 3.3.0(推荐使用)
        //  获取用户信息
        AceUser aceUser = SecurityUtils.getUser();
        if (ObjectUtil.isNotEmpty(aceUser)) {
            this.strictUpdateFill(metaObject, "updateBy", String.class, aceUser.getId());
        }
    }


}
