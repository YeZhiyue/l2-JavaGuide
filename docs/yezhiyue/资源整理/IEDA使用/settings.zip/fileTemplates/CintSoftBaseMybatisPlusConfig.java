package ${PACKAGE_NAME};

import com.baomidou.mybatisplus.core.injector.ISqlInjector;
import com.baomidou.mybatisplus.core.parser.ISqlParser;
import com.baomidou.mybatisplus.extension.plugins.PaginationInterceptor;
import com.baomidou.mybatisplus.extension.plugins.tenant.TenantSqlParser;
import com.cintsoft.ace.common.data.tenant.AceTenantConfigProperties;
import com.cintsoft.ace.common.data.tenant.AceTenantHandler;
import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.DependsOn;

import java.util.ArrayList;
import java.util.List;

/**
 * @Auther: wangzy
 * @Date: 2019/4/1 15:44
 * @Description:
 */
public class ${NAME} {

        /**
         * 创建租户维护处理器对象
         *
         * @return 处理后的租户维护处理器
         */
        @Bean
        @ConditionalOnMissingBean
        public AceTenantHandler aceTenantHandler() {
            return new AceTenantHandler();
        }

        /**
         * 分页插件
         *
         * @param aceTenantHandler 租户处理器
         * @return PaginationInterceptor
         */
        @Bean
        @ConditionalOnMissingBean
        @ConditionalOnProperty(name = "mybatisPlus.tenantEnable", havingValue = "true", matchIfMissing = true)
        public PaginationInterceptor paginationInterceptor(AceTenantHandler aceTenantHandler) {
            PaginationInterceptor paginationInterceptor = new PaginationInterceptor();
            List<ISqlParser> sqlParserList = new ArrayList<>();
            TenantSqlParser tenantSqlParser = new TenantSqlParser();
            tenantSqlParser.setTenantHandler(aceTenantHandler);
            sqlParserList.add(tenantSqlParser);
            paginationInterceptor.setSqlParserList(sqlParserList);
            return paginationInterceptor;
        }

        /**
         * 分页插件
         * @return
         */
        //@Bean
        //@ConditionalOnMissingBean
        //public PaginationInterceptor paginationInterceptor() {
        //        PaginationInterceptor paginationInterceptor = new PaginationInterceptor();
        //        //paginationInterceptor.setLocalPage(true);// 开启 PageHelper 的支持
        //        return paginationInterceptor;
        //}

        /**
         * 数据权限插件
         *
         * @param dataSource 数据源
         * @return DataScopeInterceptor
         */
        //@Bean
        //@ConditionalOnMissingBean
        //public DataScopeInterceptor dataScopeInterceptor(DataSource dataSource) {
        //    return new DataScopeInterceptor(dataSource);
        //}
}
