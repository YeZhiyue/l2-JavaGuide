// TODO 
// 叶之越, $DATE
// Class: ${SIMPLE_CLASS_NAME} 
// Method:${METHOD_NAME} 
// return:${DEFAULT_RETURN_VALUE}
#if ( $RETURN_TYPE != "void" )return $DEFAULT_RETURN_VALUE;#end