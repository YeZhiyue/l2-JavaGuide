package com.cintsoft.ace.space.provider;

import java.util.function.DoubleBinaryOperator;

#parse("File Header.java")
enum Operation {
    // 被使用时已经被构造器初始化一个单例
    PLUS("+", (x, y) -> x + y) {
        public double apply(double x, double y) {
            return x + y;
        }
    };

    // 计算类型
    private final String symbol;
    // 使用函数式接口
    private final DoubleBinaryOperator operator;

    // 作为一个单例对象的构造器
    Operation(String symbol, DoubleBinaryOperator operator) {
        this.symbol = symbol;
        this.operator = operator;
    }

    // 枚举中抽象类中的抽象方法，在我们使用枚举常量的时候已经初始化完毕了
    public abstract double apply(double x, double y);

    // 通过函数式接口进行计算，这样子简洁了代码
    public double applyByDoubleBinaryOperator(double x, double y) {
        return operator.applyAsDouble(x, y);
    }
}