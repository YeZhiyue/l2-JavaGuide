package ${PACKAGE_NAME};

#parse("File Header.java")
public class ${NAME} extends RuntimeException {

    private Integer code;
    private String msg;

    public ${NAME}() {
        super();
    }

    public ${NAME}(String msg) {
        super(msg);
        this.code = 500;
        this.msg = msg;
    }

    public ${NAME}(Integer code, String msg) {
        super(msg);
        this.code = code;
        this.msg = msg;
    }

    public ${NAME}(BusinessCode businessCode) {
        super(businessCode.getMsg());
        this.code = businessCode.getCode();
        this.msg = businessCode.getMsg();
    }

    public Integer getCode() {
        return code;
    }

    public void setCode(Integer code) {
        this.code = code;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }
}
