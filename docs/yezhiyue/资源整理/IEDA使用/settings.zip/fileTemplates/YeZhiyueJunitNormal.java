import org.junit.After;
import org.junit.Before;
import org.junit.Test;

#parse("File Header.java")
public class ${NAME} {

    @Before
    public void before() {

    }

    @After
    public void after() {

    }

    @Test
    public void test01() {

    }

    @Test
    public void test02() {

    }

    @Test
    public void test03() {

    }

    @Test
    public void test04() {

    }

}
